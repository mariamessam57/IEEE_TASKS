# week4
# CodeForWin

Solve If Statements Problems: 4, 7, 8, 12, 14, 16, 19, 20.

Solve Switch Case Problems: 1, 7, 8.

Solve Loop Statements Problems: 2, 5, 6, 9, 10, 15, 16, 21, 40.

# HackerRank

Solve Problems: Conditional Statements in C

Solve Problems: For Loop in C
